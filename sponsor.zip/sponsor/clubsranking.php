<?php
session_start();
require_once 'config.php';

/* =============================
   Fetch ranking data from DB
   ============================= */

$ranking = get_clubs_ranking();   // تأكد إنها موجودة في sponsor_config.php وترجع مصفوفة
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>UniHive — Clubs Ranking</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="sponsor.css">
</head>
<body>

<?php include 'header.php'; ?>

  <main>
    <div class="wrapper" style="padding-top:20px;padding-bottom:32px;">

      <!-- عنوان الصفحة -->
      <section style="margin-bottom:24px;">
        <h1 class="section-title">Clubs Ranking</h1>
        <p style="margin:6px 0 0;font-size:0.9rem;color:#6b7280;">
          See which clubs are leading in engagement, events, and member activity.
        </p>
      </section>

      <!-- جدول/ليست التصنيفات -->
      <section>
        <?php if (!empty($ranking)): ?>
          <div class="ranking-list" style="display:flex;flex-direction:column;gap:10px;">

            <?php foreach ($ranking as $i => $club): ?>
              <?php
                // ترتيب (1,2,3...) وميدالية لأول 3
                $position = $i + 1;
                $medal = '';
                if ($position === 1) $medal = '🥇';
                elseif ($position === 2) $medal = '🥈';
                elseif ($position === 3) $medal = '🥉';

                $clubName      = $club['club_name']      ?? '';
                $category      = $club['category']       ?? '';
                $totalPoints   = $club['total_points']   ?? 0;
                $eventsCount   = $club['events_count']   ?? 0;
                $membersCount  = $club['members_count']  ?? 0;
                $tierLabel     = $club['tier_label']     ?? '';
                $logo          = $club['logo']           ?? '';
              ?>

              <article class="ranking-row" style="
                background:#ffffff;
                border-radius:16px;
                padding:14px 16px;
                display:flex;
                align-items:center;
                justify-content:space-between;
                box-shadow:0 10px 30px rgba(15,23,42,.08);
              ">

                <!-- يسار: رقم + لوجو + اسم النادي -->
                <div style="display:flex;align-items:center;gap:14px;">

                  <div style="width:28px;text-align:center;font-weight:800;color:#4b5563;">
                    <?php echo $position; ?>
                  </div>

                  <?php if (!empty($logo)): ?>
                    <img src="<?php echo htmlspecialchars($logo); ?>"
                         alt=""
                         style="width:40px;height:40px;border-radius:999px;object-fit:cover;"
                         onerror="this.style.display='none';">
                  <?php else: ?>
                    <div style="
                      width:40px;height:40px;border-radius:999px;
                      background:#eef2ff;color:#4f46e5;
                      display:flex;align-items:center;justify-content:center;
                      font-weight:700;font-size:0.9rem;
                    ">
                      <?php echo htmlspecialchars(substr($clubName, 0, 2)); ?>
                    </div>
                  <?php endif; ?>

                  <div>
                    <div style="font-weight:700;font-size:0.98rem;color:#111827;">
                      <?php echo htmlspecialchars($clubName); ?>
                      <?php if ($medal): ?>
                        <span style="margin-left:4px;"><?php echo $medal; ?></span>
                      <?php endif; ?>
                    </div>
                    <div style="font-size:0.8rem;color:#6b7280;margin-top:2px;">
                      <?php echo htmlspecialchars($category ?: 'General'); ?>
                    </div>
                  </div>
                </div>

                <!-- يمين: النقاط + الإحصائيات + التير -->
                <div style="display:flex;align-items:center;gap:16px;font-size:0.8rem;">

                  <div style="text-align:right;">
                    <div style="font-size:0.78rem;color:#6b7280;">Points</div>
                    <div style="font-weight:700;color:#111827;"><?php echo (int)$totalPoints; ?></div>
                  </div>

                  <div style="text-align:right;">
                    <div style="font-size:0.78rem;color:#6b7280;">Events</div>
                    <div style="font-weight:600;color:#111827;"><?php echo (int)$eventsCount; ?></div>
                  </div>

                  <div style="text-align:right;">
                    <div style="font-size:0.78rem;color:#6b7280;">Members</div>
                    <div style="font-weight:600;color:#111827;"><?php echo (int)$membersCount; ?></div>
                  </div>

                  <?php if (!empty($tierLabel)): ?>
                    <span style="
                      padding:4px 10px;
                      border-radius:999px;
                      background:#fef3c7;
                      color:#92400e;
                      font-weight:600;
                      font-size:0.78rem;
                      white-space:nowrap;
                    ">
                      <?php echo htmlspecialchars($tierLabel); ?>
                    </span>
                  <?php endif; ?>

                </div>

              </article>
            <?php endforeach; ?>

          </div>
        <?php else: ?>
          <p style="color:#6b7280;font-size:0.9rem;">
            No clubs are ranked yet. Once clubs start earning points and activity, they will appear here.
          </p>
        <?php endif; ?>
      </section>

    </div>
  </main>

  <?php include 'footer.php'; ?>

</body>
</html>
