<?php
session_start();

if (!isset($_SESSION['sponsor_id']) || $_SESSION['role'] !== 'sponsor') {
    header('Location: ../login.php');
    exit;
}

require_once 'config.php';

if (!isset($_GET['club_id'])) {
    die('Club not found.');
}

$club_id = (int) $_GET['club_id'];

/**
 * Get full club info
 * You must have a function for this:
 * get_club_details($club_id)
 */
$club = get_club_details($club_id);

if (!$club) {
    die("Club not found");
}

$club_name     = $club['club_name'];
$club_desc     = $club['description'] ?: 'This club has not added a description yet.';
$club_logo     = $club['logo'];
$contact_email = $club['contact_email'];
$facebook_url  = $club['facebook_url'];
$instagram_url = $club['instagram_url'];
$linkedin_url  = $club['linkedin_url'];

$events_done   = (int) ($club['events_count'] ?? 0);
$members_count = (int) ($club['members_count'] ?? 0);
$earned_points = (int) ($club['earned_points'] ?? 0);
$sponsor_name  = $club['main_sponsor'] ?? "No sponsor yet";

$has_links = $facebook_url || $instagram_url || $linkedin_url;
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <title><?php echo htmlspecialchars($club_name); ?> — UniHive Club</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="sponsor.css">
</head>

<body>

  <?php include 'header.php'; ?>
  <div class="underbar"></div>

  <!-- HERO -->
  <section class="section hero">
    <div class="wrap">
      <div class="hero-card">

        <div class="hero-top">
          <h1>YOUR CLUB</h1>
          <div class="tag">Club Profile</div>
        </div>

        <div class="hero-pillrow">

          <!-- CLUB -->
          <div class="pill">
            <?php if ($club_logo): ?>
              <img src="<?php echo htmlspecialchars($club_logo); ?>" style="width:42px;height:42px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.8);">
            <?php else: ?>
              <div style="width:42px;height:42px;border-radius:50%;background:#242751;color:#fff;display:flex;align-items:center;justify-content:center;border:2px solid rgba(255,255,255,.8);font-weight:800;">
                <?php echo strtoupper(substr($club_name,0,2)); ?>
              </div>
            <?php endif; ?>

            <div>
              <div style="font-size:12px;opacity:.8">club name</div>
              <strong><?php echo htmlspecialchars($club_name); ?></strong>
            </div>
          </div>

          <!-- SPONSOR -->
          <div class="pill">
            <div style="width:42px;height:42px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;border:2px solid rgba(255,255,255,.8);font-weight:800;">
              SP
            </div>
            <div>
              <div style="font-size:12px;opacity:.8">sponsor name</div>
              <strong><?php echo htmlspecialchars($sponsor_name); ?></strong>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>

  <!-- ABOUT -->
  <section class="section">
    <div class="wrap">

      <h3 class="h-title">About Club</h3>
      <div class="hr"></div>

      <div class="about">
        <p><?php echo nl2br(htmlspecialchars($club_desc)); ?></p>

        <!-- CONTACT -->
        <div class="contact-strip">
          <strong>
            <?php if ($contact_email): ?>
              <a href="mailto:<?php echo htmlspecialchars($contact_email); ?>">
                <?php echo htmlspecialchars($contact_email); ?>
              </a>
            <?php else: ?>
              No contact email provided yet.
            <?php endif; ?>
          </strong>
        </div>

        <!-- LINKS -->
        <?php if ($has_links): ?>
          <h4 style="letter-spacing:.4em;text-transform:uppercase;margin:10px 0;color:#242751;">Links</h4>

          <div class="link-grid">

            <?php if ($linkedin_url): ?>
              <a class="link-tile" href="<?php echo htmlspecialchars($linkedin_url); ?>" target="_blank">
                LinkedIn
              </a>
            <?php endif; ?>

            <?php if ($instagram_url): ?>
              <a class="link-tile" href="<?php echo htmlspecialchars($instagram_url); ?>" target="_blank">
                Instagram
              </a>
            <?php endif; ?>

            <?php if ($facebook_url): ?>
              <a class="link-tile" href="<?php echo htmlspecialchars($facebook_url); ?>" target="_blank">
                Facebook
              </a>
            <?php endif; ?>

          </div>
        <?php endif; ?>

      </div>
    </div>
  </section>

  <!-- STATS -->
  <section class="section">
    <div class="wrap">

      <div class="past-events-container">Want to see past events?</div>
      <a href="pastevents.php?club_id=<?php echo $club_id; ?>" class="past-events-btn">
        📅 View Past Events
      </a>

      <div class="stats">
        <div class="stat">
          <h5>Events done</h5>
          <div class="kpi"><?php echo $events_done; ?></div>
        </div>

        <div class="stat">
          <h5>Members</h5>
          <div class="kpi"><?php echo $members_count; ?></div>
        </div>

        <div class="stat">
          <h5>Earned points</h5>
          <div class="kpi"><?php echo $earned_points; ?></div>
        </div>
      </div>

    </div>
  </section>

  <?php include 'footer.php'; ?>

</body>
</html>
