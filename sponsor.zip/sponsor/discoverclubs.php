<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['sponsor_id']) || $_SESSION['role'] !== 'sponsor') {
    header('Location: ../login.php');
    exit;
}

/**
 * نتوقع أن get_discover_clubs() ترجع أراي من:
 * club_id, club_name, description, category, logo,
 * members_count, events_count, points, sponsors_list
 */
$clubs = get_discover_clubs();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>UniHive — Discover Clubs</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="sponsor.css">
</head>
<body>

  <!-- Header -->
  <header class="site-header" style="border-bottom:1px solid #e5e7eb;">
    <div class="wrapper" style="display:flex;align-items:center;justify-content:space-between;padding:12px 0;">
      <div style="display:flex;align-items:center;gap:10px;">
        <div style="width:38px;height:38px;border-radius:999px;background:#242751;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;">
          UH
        </div>
        <div>
          <div style="font-weight:800;font-size:1.05rem;">UniHive — Sponsors</div>
          <div style="font-size:0.8rem;color:#6b7280;">Match your brand with the right clubs</div>
        </div>
      </div>

      <nav style="display:flex;gap:18px;font-size:0.9rem;">
        <a href="index.php" style="text-decoration:none;color:#4b5563;">Home</a>
        <a href="clubs_ranking.php" style="text-decoration:none;color:#4b5563;">Clubs Ranking</a>
        <a href="clubs_discover.php" style="text-decoration:none;color:#242751;font-weight:700;">Discover Clubs</a>
        <a href="events_all.php" style="text-decoration:none;color:#4b5563;">Events</a>
      </nav>
    </div>
  </header>

  <main>
    <div class="wrapper" style="padding-top:20px;padding-bottom:32px;">

      <!-- عنوان الصفحة -->
      <section style="text-align:center;margin-bottom:22px;">
        <h1 class="section-title" style="text-align:center;">Discover Clubs</h1>
        <p style="margin:6px auto 0;font-size:0.9rem;color:#6b7280;max-width:520px;">
          Browse active UniHive clubs, see their size and activity, and find where your brand fits best.
        </p>
      </section>

      <!-- شريط البحث + الفلتر -->
      <section style="margin-bottom:20px;">
        <div style="
          display:grid;
          grid-template-columns: minmax(0,1.4fr) minmax(0,0.8fr);
          gap:10px;
          max-width:820px;
          margin:0 auto;
        ">
          <!-- search -->
          <div style="position:relative;">
            <input
              id="clubSearch"
              type="text"
              placeholder="Search clubs by name…"
              style="
                width:100%;
                height:44px;
                border-radius:999px;
                border:1px solid #d1d5db;
                padding:0 14px 0 36px;
                font-size:0.9rem;
                box-shadow:0 4px 10px rgba(15,23,42,.06);
              ">
            <span style="
              position:absolute;
              left:12px;
              top:50%;
              transform:translateY(-50%);
              font-size:14px;
              color:#6b7280;
            ">🔍</span>
          </div>

          <!-- category dropdown بسيط -->
          <div>
            <select
              id="categoryFilter"
              style="
                width:100%;
                height:44px;
                border-radius:999px;
                border:1px solid #d1d5db;
                padding:0 14px;
                font-size:0.9rem;
                box-shadow:0 4px 10px rgba(15,23,42,.06);
                background:#fff;
              ">
              <option value="all">All categories</option>
              <option value="Technology">Technology</option>
              <option value="Sports">Sports</option>
              <option value="Arts">Arts</option>
              <option value="Community">Community</option>
              <option value="Science">Science</option>
            </select>
          </div>
        </div>
      </section>

      <!-- GRID الكلابز -->
      <section>
        <?php if (!empty($clubs)): ?>
          <div id="clubGrid" style="
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(260px,1fr));
            gap:18px;
          ">
            <?php foreach ($clubs as $club): ?>
              <?php
                $clubId       = (int)($club['club_id'] ?? 0);
                $name         = $club['club_name'] ?? '';
                $category     = $club['category'] ?? 'General';
                $desc         = $club['description'] ?? '';
                $logo         = $club['logo'] ?? '';
                $members      = (int)($club['members_count'] ?? 0);
                $events       = (int)($club['events_count'] ?? 0);
                $points       = (int)($club['points'] ?? 0);
                $sponsorsList = $club['sponsors_list'] ?? ''; // مثلاً "Coffee Corner, Tech Galaxy"
              ?>
              <a
                class="club-card-link"
                href="club_page.php?club_id=<?php echo $clubId; ?>"
                data-category="<?php echo htmlspecialchars($category); ?>"
                data-name="<?php echo htmlspecialchars(strtolower($name)); ?>"
                style="text-decoration:none;color:inherit;"
              >
                <article class="club-card" style="
                  background:#ffffff;
                  border-radius:18px;
                  padding:14px 14px 16px;
                  box-shadow:0 10px 26px rgba(15,23,42,.10);
                  border:1px solid #e5e7eb;
                  display:flex;
                  flex-direction:column;
                  min-height:190px;
                  transition:.15s ease;
                ">
                  <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
                    <div style="display:flex;align-items:center;gap:10px;">
                      <?php if (!empty($logo)): ?>
                        <img
                          src="<?php echo htmlspecialchars($logo); ?>"
                          alt="Logo of <?php echo htmlspecialchars($name); ?>"
                          style="width:44px;height:44px;border-radius:999px;object-fit:cover;border:2px solid #e5b758;"
                          onerror="this.style.display='none';"
                        >
                      <?php else: ?>
                        <div style="
                          width:44px;height:44px;border-radius:999px;
                          background:#eef2ff;
                          display:flex;align-items:center;justify-content:center;
                          font-weight:800;font-size:0.9rem;color:#3730a3;
                          border:2px solid #e5b758;
                        ">
                          <?php echo htmlspecialchars(substr($name,0,2)); ?>
                        </div>
                      <?php endif; ?>
                      <div>
                        <h3 style="margin:0;font-size:1rem;font-weight:800;color:#111827;max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                          <?php echo htmlspecialchars($name); ?>
                        </h3>
                        <small style="font-size:0.75rem;color:#6b7280;">
                          <?php if ($sponsorsList): ?>
                            Sponsored by <strong><?php echo htmlspecialchars($sponsorsList); ?></strong>
                          <?php else: ?>
                            Looking for sponsors
                          <?php endif; ?>
                        </small>
                      </div>
                    </div>

                    <span style="
                      font-size:0.72rem;
                      font-weight:700;
                      padding:6px 10px;
                      border-radius:999px;
                      background:#eff6ff;
                      color:#1d4ed8;
                      white-space:nowrap;
                    ">
                      <?php echo htmlspecialchars($category); ?>
                    </span>
                  </div>

                  <!-- description -->
                  <?php if (!empty($desc)): ?>
                    <p style="
                      margin:8px 2px 10px;
                      font-size:0.82rem;
                      line-height:1.5;
                      color:#4b5563;
                      max-height:3.2em;
                      overflow:hidden;
                    ">
                      <?php echo htmlspecialchars($desc); ?>
                    </p>
                  <?php endif; ?>

                  <!-- meta stats -->
                  <div style="
                    margin-top:auto;
                    display:flex;
                    flex-wrap:wrap;
                    gap:10px 16px;
                    font-size:0.78rem;
                    font-weight:700;
                    color:#374151;
                  ">
                    <span>Members: <?php echo $members; ?></span>
                    <span>Events: <?php echo $events; ?></span>
                    <span>Points: <?php echo $points; ?></span>
                  </div>
                </article>
              </a>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <p style="color:#6b7280;font-size:0.9rem;">
            No clubs found yet. Once clubs are registered in UniHive, they will appear here for sponsors to explore.
          </p>
        <?php endif; ?>
      </section>

    </div>
  </main>

  <footer class="site-footer" style="border-top:1px solid #e5e7eb;margin-top:20px;">
    <div class="wrapper" style="padding:12px 0;font-size:0.8rem;color:#6b7280;display:flex;justify-content:space-between;">
      <span>© <?php echo date('Y'); ?> UniHive Sponsors.</span>
      <span>Discover your next club partnership.</span>
    </div>
  </footer>

  <script>
    (function(){
      const searchInput = document.getElementById('clubSearch');
      const catSelect   = document.getElementById('categoryFilter');
      const cards       = Array.from(document.querySelectorAll('#clubGrid .club-card-link'));

      if (!searchInput || !catSelect || !cards.length) return;

      function applyFilters(){
        const q   = searchInput.value.trim().toLowerCase();
        const cat = catSelect.value;

        cards.forEach(card => {
          const name = (card.dataset.name || '').toLowerCase();
          const c    = card.dataset.category || '';

          const matchName = !q || name.includes(q);
          const matchCat  = (cat === 'all') || (c === cat);

          card.style.display = (matchName && matchCat) ? '' : 'none';
        });
      }

      searchInput.addEventListener('input', applyFilters);
      catSelect.addEventListener('change', applyFilters);
    })();
  </script>

</body>
</html>
