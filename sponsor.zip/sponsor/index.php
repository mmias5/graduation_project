<?php
session_start();
require_once 'config.php';

/* =============================
   Fetch real data from database
   ============================= */

$topClubs       = get_top_clubs_for_home(3);
$upcomingEvents = get_upcoming_events();
$discoverClubs  = get_active_clubs_for_discover();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>UniHive — Sponsor Portal</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="sponsor.css">
</head>
<body>

  <!-- Header -->
<?php include 'header.php'; ?>
  <main>
    <div class="wrapper">

      <!-- HERO VIDEO -->
      <section class="hero">
        <video autoplay muted loop playsinline>
          <source src="assets/campus_hero.mp4" type="video/mp4">
        </video>
        <div class="hero-overlay"></div>
        <div class="hero-content">
          <div class="hero-title">Reach the right students — faster.</div>
          <div class="hero-sub">Use UniHive analytics to choose clubs and events that match your brand.</div>
        </div>
      </section>

      <!-- BI Placeholder -->
      <section class="bi-box">
        Power BI Dashboard Embed Placeholder
      </section>

      <!-- BEST OF CAMPUS -->
      <section>
        <h2 class="section-title">Best of Campus this Month</h2>
        <div class="ranking-list">

          <?php if (!empty($topClubs)): ?>
            <?php foreach ($topClubs as $i => $club): ?>
              <div class="ranking-row <?php echo $i === 0 ? 'top' : ''; ?>">
                <div class="left">
                  <div class="club-badge">
                    <?php echo htmlspecialchars(substr($club['club_name'], 0, 2)); ?>
                  </div>
                  <div>
                    <div class="club-text-main">
                      <?php echo htmlspecialchars($club['club_name']); ?>
                    </div>
                    <div class="club-text-sub">
                      <?php echo htmlspecialchars($club['sponsor_name'] ?: 'No sponsor'); ?>
                    </div>
                  </div>
                </div>
                <div class="ranking-medal">
                  <?php echo ['🥇','🥈','🥉'][$i] ?? '🎖️'; ?>
                </div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p style="color:#6b7280;">No ranking data available.</p>
          <?php endif; ?>

        </div>
      </section>

      <!-- TWO SECTION GRID -->
      <section style="display:grid;grid-template-columns:minmax(0,1.2fr) minmax(0,1fr);gap:28px;margin-bottom:40px;">

        <!-- UPCOMING EVENTS -->
        <div>
          <h2 class="section-title">Highlighted Events</h2>
          <div class="grid">

            <?php if (!empty($upcomingEvents)): ?>
              <?php foreach ($upcomingEvents as $ev): 
                $start = strtotime($ev['starting_date']);
                $mon   = strtoupper(date('M', $start));
                $day   = date('d', $start);
              ?>
                <article class="card" onclick="window.location.href='event_details.php?event_id=<?php echo $ev['event_id']; ?>';">
                  <div class="topline">
                    <div class="badge">Event</div>
                    <span class="state completed" style="background:#16a34a;">Upcoming</span>
                  </div>

                  <div class="date">
                    <div class="month"><?php echo $mon; ?></div>
                    <div class="day"><?php echo $day; ?></div>
                  </div>

                  <div class="title"><?php echo htmlspecialchars($ev['event_name']); ?></div>
                  <div class="mini">
                    <?php echo htmlspecialchars($ev['club_name']); ?> · <?php echo htmlspecialchars($ev['event_location']); ?>
                  </div>
                </article>
              <?php endforeach; ?>

            <?php else: ?>
              <p style="color:#6b7280;">No upcoming events.</p>
            <?php endif; ?>

          </div>
        </div>

        <!-- DISCOVER CLUBS -->
        <div>
          <h2 class="section-title">Clubs to Watch</h2>
          <div class="club-grid">

            <?php if (!empty($discoverClubs)): ?>
              <?php foreach ($discoverClubs as $c): ?>
                <article class="club-card" onclick="window.location.href='club_page.php?club_id=<?php echo $c['club_id']; ?>';">
                  <div class="club-head">
                    <div style="display:flex;align-items:center;">
                      <img src="<?php echo htmlspecialchars($c['logo']); ?>"
                           class="club-logo"
                           onerror="this.style.display='none';">
                      <div>
                        <div style="font-weight:700;"><?php echo htmlspecialchars($c['club_name']); ?></div>
                        <div style="font-size:0.8rem;color:#6b7280;">
                          Events: <?php echo (int)$c['events_count']; ?>
                        </div>
                      </div>
                    </div>
                    <span class="category-chip"><?php echo htmlspecialchars($c['category']); ?></span>
                  </div>

                  <p class="club-desc"><?php echo htmlspecialchars($c['description'] ?? ''); ?></p>
                </article>
              <?php endforeach; ?>

            <?php else: ?>
              <p style="color:#6b7280;">No active clubs found.</p>
            <?php endif; ?>

          </div>
        </div>

      </section>

    </div>
  </main>

  <?php include 'footer.php'; ?>

</body>
</html>
