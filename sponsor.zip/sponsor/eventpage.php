<?php
session_start();
require_once 'config.php';

if (!isset($_GET['event_id'])) {
    die("Event not found.");
}
$event_id = (int) $_GET['event_id'];

/*
  نتوقع أن get_event_details($event_id) ترجع:
  event_name, description, event_location, starting_date,
  ending_date, club_name, event_image
*/
$ev = get_event_details($event_id);

if (!$ev) {
    die("Event not found in database.");
}

$start = strtotime($ev['starting_date']);
$mon   = strtoupper(date('M', $start));
$day   = date('d', $start);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title><?php echo htmlspecialchars($ev['event_name']); ?> — UniHive Event</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="sponsor.css">
</head>
<body>

<!-- HEADER -->
<header class="site-header" style="border-bottom:1px solid #e5e7eb;">
  <div class="wrapper" style="display:flex;align-items:center;justify-content:space-between;padding:12px 0;">
    
    <div style="display:flex;align-items:center;gap:10px;">
      <div style="width:38px;height:38px;border-radius:999px;background:#242751;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;">
        UH
      </div>
      <div>
        <div style="font-weight:800;font-size:1.05rem;">UniHive — Sponsors</div>
        <div style="font-size:0.8rem;color:#6b7280;">Event Details</div>
      </div>
    </div>

    <nav style="display:flex;gap:18px;font-size:0.9rem;">
      <a href="index.php" style="text-decoration:none;color:#4b5563;">Home</a>
      <a href="clubs_ranking.php" style="text-decoration:none;color:#4b5563;">Clubs Ranking</a>
      <a href="clubs_discover.php" style="text-decoration:none;color:#4b5563;">Discover Clubs</a>
      <a href="events_all.php" style="text-decoration:none;color:#242751;font-weight:700;">Events</a>
    </nav>

  </div>
</header>

<main>
  <div class="wrapper" style="padding-top:20px;padding-bottom:32px;max-width:760px;">

    <!-- EVENT IMAGE -->
    <?php if (!empty($ev['event_image'])): ?>
      <section class="event-hero">
        <img src="<?php echo htmlspecialchars($ev['event_image']); ?>"
             alt="Event Image"
             onerror="this.style.display='none';">
      </section>
    <?php endif; ?>

    <!-- EVENT DETAILS BLOCK -->
    <section class="event-block">

      <h1 class="event-title">
        <?php echo htmlspecialchars($ev['event_name']); ?>
      </h1>

      <div class="event-sub">
        Organized by <?php echo htmlspecialchars($ev['club_name']); ?>
      </div>

      <hr style="margin:18px 0; border:none; border-top:1px solid #e5e7eb;">

      <!-- DATE -->
      <p style="font-size:0.95rem;margin-bottom:6px;">
        <strong>Date:</strong>
        <?php echo date("F d, Y", $start); ?>
      </p>

      <!-- LOCATION -->
      <p style="font-size:0.95rem;margin-bottom:16px;">
        <strong>Location:</strong>
        <?php echo htmlspecialchars($ev['event_location']); ?>
      </p>

      <!-- DESCRIPTION -->
      <?php if (!empty($ev['description'])): ?>
        <div style="font-size:0.95rem;line-height:1.6;color:#374151;">
          <?php echo nl2br(htmlspecialchars($ev['description'])); ?>
        </div>
      <?php endif; ?>

    </section>

  </div>
</main>

<footer class="site-footer" style="border-top:1px solid #e5e7eb;margin-top:20px;">
  <div class="wrapper" style="padding:12px 0;font-size:0.8rem;color:#6b7280;display:flex;justify-content:space-between;">
    <span>© <?php echo date('Y'); ?> UniHive Sponsors.</span>
    <span>Event insights made simple.</span>
  </div>
</footer>

</body>
</html>
