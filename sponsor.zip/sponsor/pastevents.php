<?php
session_start();

if (!isset($_SESSION['sponsor_id']) || $_SESSION['role'] !== 'sponsor') {
    header('Location: ../login.php');
    exit;
}

require_once 'config.php';

$sponsorId = (int)$_SESSION['sponsor_id'];
$clubId    = isset($_GET['club_id']) ? (int)$_GET['club_id'] : 0;

$clubName = null;
if ($clubId > 0) {
    $stmtClub = $conn->prepare("SELECT club_name FROM club WHERE club_id = ?");
    if ($stmtClub) {
        $stmtClub->bind_param('i', $clubId);
        $stmtClub->execute();
        $resClub = $stmtClub->get_result();
        if ($rowClub = $resClub->fetch_assoc()) {
            $clubName = $rowClub['club_name'];
        }
        $stmtClub->close();
    }
}

$sql = "
    SELECT 
        e.event_id,
        e.event_name,
        e.event_location,
        e.starting_date,
        e.ending_date,
        c.club_name,
        s.company_name AS sponsor_name,
        ROUND(AVG(r.rating), 1) AS avg_rating
    FROM event e
    INNER JOIN club c 
        ON e.club_id = c.club_id
    INNER JOIN sponsor_club_support scs 
        ON scs.club_id = c.club_id
    INNER JOIN sponsor s
        ON s.sponsor_id = scs.sponsor_id
    LEFT JOIN rating r 
        ON r.event_id = e.event_id
    WHERE 
        scs.sponsor_id = ?
        AND e.ending_date < NOW()
";

$params = [$sponsorId];
$types  = 'i';

if ($clubId > 0) {
    $sql   .= " AND e.club_id = ? ";
    $params[] = $clubId;
    $types .= 'i';
}

$sql .= "
    GROUP BY 
        e.event_id,
        e.event_name,
        e.event_location,
        e.starting_date,
        e.ending_date,
        c.club_name,
        s.company_name
    ORDER BY e.ending_date DESC
";

$events = [];

$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
    $stmt->close();
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>UniHive — Past Events</title>

  <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="sponsors.css">
</head>
<body>

<div class="wrapper">
  <h1 class="page-title">
    <?php if ($clubName): ?>
      Past Events — <?php echo htmlspecialchars($clubName); ?>
    <?php else: ?>
      Past Events
    <?php endif; ?>
  </h1>

  <p class="subtle">
    <?php if ($clubName): ?>
      Explore what this club has already organized — completed events, sponsors, and engagement.
    <?php else: ?>
      Explore completed events across the clubs you support on UniHive.
    <?php endif; ?>
  </p>

  <section class="section">
    <h2>Completed Events</h2>

    <?php if (empty($events)): ?>
      <p class="subtle">No past events found yet for this view.</p>
    <?php else: ?>
      <div class="grid">
        <?php foreach ($events as $event): ?>
          <?php
            $start = $event['starting_date'] ? new DateTime($event['starting_date']) : null;
            if ($start) {
                $day  = $start->format('d');
                $mon  = strtoupper($start->format('M'));
                $week = $start->format('D');
            } else {
                $day = '--'; $mon = '--'; $week = '';
            }

            $rating = $event['avg_rating'];
            $ratingDisplay = $rating !== null ? number_format($rating, 1) : 'N/A';
            $ratingValue   = $rating !== null ? (float)$rating : 0;
          ?>

          <article
            class="card"
            data-href="eventpage.php?event_id=<?php echo (int)$event['event_id']; ?>"
            role="link"
            tabindex="0"
            aria-label="Open event: <?php echo htmlspecialchars($event['event_name']); ?> (past)">
            <div class="date">
              <div class="day"><?php echo htmlspecialchars($day); ?></div>
              <div class="mon"><?php echo htmlspecialchars($mon); ?></div>
              <div class="sep"><?php echo htmlspecialchars($week); ?></div>
            </div>
            <div>
              <div class="topline">
                <span class="state completed">Completed</span>
                <span class="chip sponsor">
                  Sponsor:
                  <?php echo htmlspecialchars($event['sponsor_name']); ?>
                </span>
              </div>
              <div class="title">
                <?php echo htmlspecialchars($event['club_name']); ?> — 
                <?php echo htmlspecialchars($event['event_name']); ?>
              </div>
              <div class="mini">
                <?php if (!empty($event['event_location'])): ?>
                  <span>📍 <?php echo htmlspecialchars($event['event_location']); ?></span>
                <?php endif; ?>
              </div>
              <div class="footer">
                <span class="review">
                  <span class="stars" style="--rating:<?php echo htmlspecialchars($ratingValue); ?>"></span>
                  <?php echo htmlspecialchars($ratingDisplay); ?>
                </span>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </section>
</div>

<script>
(function(){
  function shouldIgnore(target){
    const interactive = ['A','BUTTON','INPUT','SELECT','TEXTAREA','LABEL','SVG','PATH'];
    return interactive.includes(target.tagName);
  }

  document.addEventListener('click', (e) => {
    const card = e.target.closest('.card[data-href]');
    if(!card) return;
    if(shouldIgnore(e.target)) return;
    const url = card.getAttribute('data-href');
    if(url) window.location.href = url;
  });

  document.addEventListener('keydown', (e) => {
    if(e.key !== 'Enter' && e.key !== ' ') return;
    const card = e.target.closest('.card[data-href]');
    if(!card) return;
    e.preventDefault();
    const url = card.getAttribute('data-href');
    if(url) window.location.href = url;
  });
})();
</script
