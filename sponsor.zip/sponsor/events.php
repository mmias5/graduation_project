<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['sponsor_id']) || $_SESSION['role'] !== 'sponsor') {
    header('Location: ../login.php');
    exit;
}

/*
  توقعات الدالة:
  get_all_events_for_sponsor() ترجع:
  event_id, event_name, event_location, starting_date,
  ending_date, club_name, event_image
*/

$events = get_all_events_for_sponsor();

?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>UniHive — All Events</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="sponsor.css">
</head>
<body>

<!-- HEADER -->
<header class="site-header" style="border-bottom:1px solid #e5e7eb;">
  <div class="wrapper" style="display:flex;align-items:center;justify-content:space-between;padding:12px 0;">
    
    <div style="display:flex;align-items:center;gap:10px;">
      <div style="width:38px;height:38px;border-radius:999px;background:#242751;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;">
        UH
      </div>
      <div>
        <div style="font-weight:800;font-size:1.05rem;">UniHive — Sponsors</div>
        <div style="font-size:0.8rem;color:#6b7280;">Browse upcoming and past university events</div>
      </div>
    </div>

    <nav style="display:flex;gap:18px;font-size:0.9rem;">
      <a href="index.php" style="text-decoration:none;color:#4b5563;">Home</a>
      <a href="clubs_ranking.php" style="text-decoration:none;color:#4b5563;">Clubs Ranking</a>
      <a href="clubs_discover.php" style="text-decoration:none;color:#4b5563;">Discover Clubs</a>
      <a href="events_all.php" style="text-decoration:none;color:#242751;font-weight:700;">Events</a>
    </nav>

  </div>
</header>

<main>
  <div class="wrapper" style="padding-top:22px;padding-bottom:28px;">

    <!-- Title -->
    <section style="margin-bottom:20px;">
      <h1 class="section-title">All Events</h1>
      <p style="color:#6b7280;font-size:0.9rem;">See what's happening across campus activities.</p>
    </section>

    <!-- Filters -->
    <section style="margin-bottom:20px;">
      <div style="display:flex;gap:12px;">
        <button id="btn-upcoming"
          style="padding:8px 18px;border-radius:999px;border:1px solid #4871db;background:#4871db;color:#fff;cursor:pointer;font-weight:600;">
          Upcoming
        </button>

        <button id="btn-past"
          style="padding:8px 18px;border-radius:999px;border:1px solid #d1d5db;background:#fff;color:#374151;cursor:pointer;font-weight:600;">
          Past
        </button>
      </div>
    </section>

    <!-- Events Grid -->
    <section>
      <?php if (!empty($events)): ?>
        <div id="eventsGrid" class="grid">

          <?php
            $today = strtotime(date("Y-m-d"));
            foreach ($events as $ev):
              $startTimestamp = strtotime($ev['starting_date']);
              $mon = strtoupper(date('M', $startTimestamp));
              $day = date('d', $startTimestamp);
              $isPast = ($startTimestamp < $today);
          ?>

          <article
            class="card event-card"
            data-type="<?php echo $isPast ? 'past' : 'upcoming'; ?>"
            onclick="window.location.href='event_details.php?event_id=<?php echo $ev['event_id']; ?>';"
          >

            <div class="topline">
              <div class="badge"><?php echo htmlspecialchars($ev['club_name']); ?></div>
              <?php if ($isPast): ?>
                <span class="state completed">Past</span>
              <?php else: ?>
                <span class="state completed" style="background:#16a34a;">Upcoming</span>
              <?php endif; ?>
            </div>

            <div class="date">
              <div class="month"><?php echo $mon; ?></div>
              <div class="day"><?php echo $day; ?></div>
            </div>

            <div class="title"><?php echo htmlspecialchars($ev['event_name']); ?></div>
            <div class="mini">
              <?php echo htmlspecialchars($ev['event_location']); ?>
            </div>

          </article>

          <?php endforeach; ?>

        </div>
      <?php else: ?>
        <p style="color:#6b7280;">No events found.</p>
      <?php endif; ?>
    </section>

  </div>
</main>

<footer class="site-footer" style="border-top:1px solid #e5e7eb;margin-top:20px;">
  <div class="wrapper" style="padding:12px 0;font-size:0.8rem;color:#6b7280;display:flex;justify-content:space-between;">
    <span>© <?php echo date('Y'); ?> UniHive Sponsors.</span>
    <span>Explore campus event opportunities.</span>
  </div>
</footer>

<script>
  // Filter Buttons Logic
  const btnUpcoming = document.getElementById('btn-upcoming');
  const btnPast = document.getElementById('btn-past');
  const cards = document.querySelectorAll('.event-card');

  btnUpcoming.onclick = () => {
    cards.forEach(card => {
      card.style.display = (card.dataset.type === 'upcoming') ? '' : 'none';
    });
    btnUpcoming.style.background = '#4871db';
    btnUpcoming.style.color = '#fff';
    btnPast.style.background = '#fff';
    btnPast.style.color = '#374151';
  };

  btnPast.onclick = () => {
    cards.forEach(card => {
      card.style.display = (card.dataset.type === 'past') ? '' : 'none';
    });
    btnPast.style.background = '#4871db';
    btnPast.style.color = '#fff';
    btnUpcoming.style.background = '#fff';
    btnUpcoming.style.color = '#374151';
  };
</script>

</body>
</html>
