<?php
// sponsor_config.php
// هذا الملف يحتوي على كل الدوال المشتركة الخاصة بـ Sponsor Portal

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// اتصال قاعدة البيانات الرئيسي
require_once '/../config.php'; // يتوقع أن يحتوي على $conn (mysqli)

// أمان بسيط: تأكد أن $conn موجود
if (!isset($conn)) {
    die("Database connection \$conn is not defined in config.php");
}

/**
 * إرجاع بيانات السبونسر الحالي من جدول sponsor
 */
function getSponsorById($sponsor_id)
{
    global $conn;

    $sql = "SELECT sponsor_id, company_name, email, phone, logo 
            FROM sponsor 
            WHERE sponsor_id = ? 
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $sponsor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row    = $result->fetch_assoc();
    $stmt->close();

    return $row ?: null;
}

/**
 * جلب كل الكلوبز المدعومة من هذا السبونسر + نقاطهم وأعداد الفعاليات
 * تُستخدم في:
 *  - clubsranking.php
 *  - ممكن لاحقاً في الصفحة الرئيسية (Top clubs)
 */
function getSponsorClubsRanking($sponsor_id)
{
    global $conn;

    $sql = "
        SELECT 
            c.club_id,
            c.club_name,
            c.description,
            c.category,
            c.logo,
            c.member_count,
            c.points,
            COUNT(DISTINCT e.event_id) AS events_count
        FROM sponsor_club_support scs
        INNER JOIN club c 
            ON c.club_id = scs.club_id
        LEFT JOIN event e 
            ON e.club_id = c.club_id
        WHERE scs.sponsor_id = ?
        GROUP BY 
            c.club_id,
            c.club_name,
            c.description,
            c.category,
            c.logo,
            c.member_count,
            c.points
        ORDER BY c.points DESC, events_count DESC
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $sponsor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows   = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return $rows;
}

/**
 * جلب الكلوبز النشيطة التي لا يدعمها هذا السبونسر (Discover Clubs)
 * تُستخدم في discoverclubs.php
 */
function getDiscoverClubsForSponsor($sponsor_id)
{
    global $conn;

    $sql = "
        SELECT 
            c.club_id,
            c.club_name,
            c.description,
            c.category,
            c.logo,
            c.member_count,
            c.points
        FROM club c
        WHERE 
            c.status = 'active'
            AND c.club_id NOT IN (
                SELECT scs.club_id 
                FROM sponsor_club_support scs
                WHERE scs.sponsor_id = ?
            )
        ORDER BY c.points DESC, c.member_count DESC, c.club_name ASC
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $sponsor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows   = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return $rows;
}

/**
 * جلب الفعاليات القادمة للكلوبز المدعومة من السبونسر
 * تُستخدم في upcomings events page (events.php)
 */
function getUpcomingEventsForSponsor($sponsor_id)
{
    global $conn;

    $sql = "
        SELECT 
            e.event_id,
            e.event_name,
            e.description,
            e.event_location,
            e.max_attendees,
            e.starting_date,
            e.ending_date,
            e.attendees_count,
            e.banner_image,
            c.club_id,
            c.club_name,
            s.company_name AS sponsor_name
        FROM event e
        INNER JOIN club c 
            ON c.club_id = e.club_id
        INNER JOIN sponsor_club_support scs 
            ON scs.club_id = c.club_id
        INNER JOIN sponsor s 
            ON s.sponsor_id = scs.sponsor_id
        WHERE 
            scs.sponsor_id = ?
            AND e.starting_date >= NOW()
        ORDER BY e.starting_date ASC
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $sponsor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows   = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return $rows;
}

/**
 * جلب تفاصيل إيفنت واحد مع الكلوب + السبونسر (لو موجود)
 * تُستخدم في eventpage.php
 */
function getEventDetailsForSponsor($event_id, $sponsor_id = null)
{
    global $conn;

    // لو حابة تتأكدي أن السبونسر فعلاً يدعم الكلوب، نستخدم sponsor_id، 
    // لو مش مهم نقدر نتجاهل الشرط.
    if ($sponsor_id !== null) {
        $sql = "
            SELECT 
                e.*,
                c.club_name,
                c.club_id,
                c.logo AS club_logo,
                s.sponsor_id,
                s.company_name AS sponsor_name
            FROM event e
            INNER JOIN club c 
                ON c.club_id = e.club_id
            LEFT JOIN sponsor_club_support scs 
                ON scs.club_id = c.club_id AND scs.sponsor_id = ?
            LEFT JOIN sponsor s 
                ON s.sponsor_id = scs.sponsor_id
            WHERE e.event_id = ?
            LIMIT 1
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ii', $sponsor_id, $event_id);
    } else {
        $sql = "
            SELECT 
                e.*,
                c.club_name,
                c.club_id,
                c.logo AS club_logo
            FROM event e
            INNER JOIN club c 
                ON c.club_id = e.club_id
            WHERE e.event_id = ?
            LIMIT 1
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $event_id);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $row    = $result->fetch_assoc();
    $stmt->close();

    return $row ?: null;
}

/**
 * جلب تفاصيل كلوب واحد + إحصائيات بسيطة
 * تُستخدم في clubpage.php
 */
function getClubDetailsWithStats($club_id)
{
    global $conn;

    $sql = "
        SELECT 
            c.club_id,
            c.club_name,
            c.description,
            c.category,
            c.logo,
            c.contact_email,
            c.facebook_url,
            c.instagram_url,
            c.linkedin_url,
            c.member_count,
            c.points,
            COUNT(DISTINCT e.event_id) AS events_count
        FROM club c
        LEFT JOIN event e 
            ON e.club_id = c.club_id
        WHERE c.club_id = ?
        GROUP BY 
            c.club_id,
            c.club_name,
            c.description,
            c.category,
            c.logo,
            c.contact_email,
            c.facebook_url,
            c.instagram_url,
            c.linkedin_url,
            c.member_count,
            c.points
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $club_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row    = $result->fetch_assoc();
    $stmt->close();

    return $row ?: null;
}

/**
 * جلب الفعاليات السابقة لكلوب معيّن + متوسط التقييم
 * تُستخدم في:
 *  - pastevents.php
 *  - ممكن أيضاً في clubpage.php تحت "Past Events"
 */
function getPastEventsByClub($club_id)
{
    global $conn;

    $sql = "
        SELECT 
            e.event_id,
            e.event_name,
            e.event_location,
            e.starting_date,
            e.ending_date,
            e.banner_image,
            ROUND(AVG(r.rating), 1) AS avg_rating,
            COUNT(DISTINCT r.rating_id) AS rating_count
        FROM event e
        LEFT JOIN rating r 
            ON r.event_id = e.event_id
        WHERE 
            e.club_id = ?
            AND e.ending_date < NOW()
        GROUP BY 
            e.event_id,
            e.event_name,
            e.event_location,
            e.starting_date,
            e.ending_date,
            e.banner_image
        ORDER BY e.ending_date DESC
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $club_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows   = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return $rows;
}
